echo Enter a number
flag=0
read a;
for (( i=2; i<a; i++ ))
do
b=`expr $a % $i`
if [ $b -eq 0 ]
then
flag=1
fi
done
if [ $flag -eq 1 ]
then
echo number is composite
else
echo number is prime
fi
