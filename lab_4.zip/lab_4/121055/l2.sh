echo Enter any character;
read a;
b= grep $a sny.sh;
if [ $? -eq 0 ]
then              
echo character found ;
fi
