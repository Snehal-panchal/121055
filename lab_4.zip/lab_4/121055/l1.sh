ch='y'
while [ $ch = 'y' -o $ch = 'Y' ]
do
        s=0
        n=0
        flag=0
        while [ $flag -eq 0 ]
        do
                echo -n "Enter the no:="
                read n
                if [ $n -lt 50 ]
                then
                        flag=1
                else
                        echo "Number must be less then 50"
                fi
        done 
   s=0
        s=`expr $n \* $n`
        echo "The square of $n:= $s"
        echo "Do you want to continue:= Y/N"
        read ch
done
