echo "Enter your salary : "
read salary
echo Enter percentage of HRA;
read per;

fin=`echo  $salary \* $per / 100 | bc`

echo "Gross salary: $fin"
