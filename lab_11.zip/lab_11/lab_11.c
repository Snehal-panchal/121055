#include<stdio.h>
void main()
{
int p_n,i,p_w,k,tmp,m,l;
printf("\nEnter the no of process:");
scanf("%d",&p_n);
int exc[p_n],start[p_n],dead_line[p_n], flag[p_n];
for(i=0;i<p_n;i++)
flag[p_n] = 0;
p_w = 0;
 for(i=0;i<p_n;i++)
 {
 	printf("\nEnter start time,exc time&deadline for process %d:",i+1);
 	scanf("%d %d %d",&start[i],&exc[i],&dead_line[i]);
 }
	
		 int time_quatm=0;
		 int end_false=1;
		 int nearest_dead_line=10000;
		 int index=-1;
		 int cnt=0;
	 while(end_false)
	 {
	for(i=0;i<p_n;i++)
		{
		if(start[i] == time_quatm || exc[index] == 0)
			{
				if(flag[i] != 1)
				{
					if(((dead_line[i]-time_quatm)-exc[i])<small_slck)
					{
						small_slck=(dead_line[i]-time_quatm);
						index=i;
					}
				}
			}
			
			
		}
		if(exc[index] == 0)
				{
					nearest_dead_line = 10000;
					index=-1;
				}
		if(index!=-1)
		{
			printf("\n from time quantum %d to %d, proc %d",time_quatm,time_quatm+1,index+1);
			exc[index]--;
		if(exc[index] == 0)
		{
			flag[index]=1;
			cnt++;
		}
		}
		if(cnt == p_n)
			end_false = 0;
		time_quatm++;
	 }
	 
}