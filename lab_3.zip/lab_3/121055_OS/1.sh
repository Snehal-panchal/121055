/*program 1 : Write a shell script to scan two variables and to display their sum, mul, div, sub and modulo division.*/

echo Enter a number;
read a;
echo Enter another number;
read b;
echo Addition is` expr $a + $b `;
echo Multiplication is` expr $a \* $b `;
echo Division is` expr $a \/ $b `;
echo Subtraction is` expr $a - $b `;
echo Modulation is` expr $a \% $b `;




