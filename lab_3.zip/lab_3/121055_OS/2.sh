/*second:1. Write a shell script to perform all Arithmetic Operations using Command line arguments.*/


add = `expr $a + $b`
Echo “The addition is :- $add″
sub = `expr $a - $b`
Echo “The subtraction is :- $sub″
mul = `expr $a * $b`
Echo “The multiplication is :- $mul″
div = `expr $a / $b`
Echo “The Average is :- $div″
mod = `expr $a % $b`
Echo “The modulation is :- $mod″


