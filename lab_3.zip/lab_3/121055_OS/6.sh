/*Write a shell script to perform all Arithmetic Operations using Command line arguments. */
//sixth
echo enter command name ;
read a ;
echo enter value to be executed ;
read b ;
$a $b ;

